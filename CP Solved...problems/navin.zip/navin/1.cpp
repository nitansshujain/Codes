#include <bits/stdc++.h>
using namespace std;

bool compare(const pair<int, int> &p1, const pair<int, int> &p2)
{
    if (p1.first == p2.first)
        return p2.second < p2.second;
    return p1.first > p2.first;
}
int main()
{
    vector<pair<int, int>> v;
    v.push_back({1, 11});
    v.push_back(make_pair(1, 11));
    v.pop_back();
    v.push_back({2, 1});
    v.push_back({1, 111});
    v.push_back({3, 11});
    v.pop_back();

    for (int i = 0; i < 5; i++)
    {
        v.push_back({1, 2});
        v.pop_back();
    }
    sort(v.begin(), v.end(), compare);

    for (auto &p : v)
    {
        cout << p.first << " " << p.second << endl;
    }
}