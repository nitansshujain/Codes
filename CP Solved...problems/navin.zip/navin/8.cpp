#include <bits/stdc++.h>
using namespace std;
class navin
{
public:
    int a;
    navin()
    {
        a = 0;
    }
    void operator++(int)
    {
        a += 3;
    }
    void print()
    {
        cout << a << endl;
    }
};
int main()
{
    navin n;
    for (int i = 0; i < 5; i++)
        ++n;
    n.print();
    return 0;
}

/*
1. 12
2. 5
3. Error, because ++ operator cannot be overloaded
4. Error, may be due to some other reason   (Correct answer)
5. None of them
*/