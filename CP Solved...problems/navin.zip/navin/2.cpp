#include <bits/stdc++.h>
using namespace std;
typedef tuple<int, int, int> tp;

int main()
{
    priority_queue<tp, vector<tp>, greater<tp>> pq;
    int j = 10;
    for (int i = 3; i > 0; i--)
    {
        pq.push(make_tuple(i, i + 1, j++));
    }

    while (!pq.empty())
    {
        auto [a, b, c] = pq.top();
        pq.pop();

        cout << a << b << c << endl;
    }
}