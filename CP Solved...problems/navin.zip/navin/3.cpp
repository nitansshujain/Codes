#include <bits/stdc++.h>
using namespace std;
class navin
{
public:
    int a, b;
    navin(int a, int b)
    {
        this->a = a;
        this->b = b;
    }
};
class compare
{
public:
    bool operator()(navin &n1, navin &n2)
    {
        return n1.a < n2.a;
    }
};
int main()
{
    priority_queue<navin, vector<navin>, compare> pq;

    for (int i = 0; i < 3; i++)
    {
        pq.push(navin(i, i + 1));
    }

    while (!pq.empty())
    {
        auto temp = pq.top();
        pq.pop();

        cout << temp.a << " " << temp.b << endl;
    }
    return 0;
}